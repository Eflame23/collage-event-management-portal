import { useEffect, useRef, useState } from "react";
import {
  CircleAlert,
  CircleCheck,
  Eye,
  EyeOff,
  GraduationCap,
  LockKeyhole,
  LogIn,
  Moon,
  ShieldCheck,
  Sun,
  Users,
} from "lucide-react";
import crestAsset from "@/assets/mit-adt-logo.jpg.asset.json";
import {
  AUTH_ERROR_MESSAGE,
  DEMO_PASSWORD,
  ROLES,
  ROLE_PROFILES,
  validatePassword,
  type Role,
} from "./portal-logic";

interface LoginScreenProps {
  theme: "light" | "dark";
  onThemeToggle: () => void;
  /** Called only after the password has been validated. */
  onSignIn: (role: Role) => void;
}

const ROLE_ICONS: Record<Role, typeof GraduationCap> = {
  Student: GraduationCap,
  "Faculty / Club Organizer": Users,
  Administrator: ShieldCheck,
};

export function LoginScreen({ theme, onThemeToggle, onSignIn }: LoginScreenProps) {
  const [selected, setSelected] = useState<Role | null>(null);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const passwordRef = useRef<HTMLInputElement>(null);

  // Choosing an account moves focus straight to the password field.
  useEffect(() => {
    if (selected) passwordRef.current?.focus();
  }, [selected]);

  const selectRole = (role: Role) => {
    setSelected(role);
    setPassword("");
    setError(null);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    // TC02: an empty or wrong password never gets past this check.
    if (!validatePassword(password)) {
      setError(AUTH_ERROR_MESSAGE);
      passwordRef.current?.focus();
      passwordRef.current?.select();
      return;
    }
    // TC01: valid password -> hand the role to PortalApp, which stores the session.
    setError(null);
    onSignIn(selected);
  };

  const selectedProfile = selected ? ROLE_PROFILES[selected] : null;

  return (
    <div className="grid min-h-screen grid-cols-1 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
      {/* Brand panel */}
      <aside className="relative flex flex-col justify-between overflow-hidden bg-[#360D3A] px-8 py-10 text-white lg:px-14 lg:py-14">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-24 size-80 rounded-full bg-[#B8860B]/15 blur-3xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-32 -left-16 size-96 rounded-full bg-white/5 blur-3xl"
        />

        <div className="relative flex items-center gap-4">
          <span className="flex size-16 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white shadow-md ring-2 ring-[#B8860B] sm:size-20">
            <img
              src={crestAsset.url}
              alt="MIT-ADT University crest"
              className="size-full object-cover"
            />
          </span>
          <div className="leading-tight">
            <p className="font-display text-lg font-bold tracking-wider sm:text-xl">
              MIT-ADT UNIVERSITY
            </p>
            <p className="mt-0.5 text-xs font-semibold text-[#E3B341] sm:text-sm">
              Campus Event Management Portal
            </p>
          </div>
        </div>

        <div className="relative mt-10 lg:mt-0">
          <h1 className="font-display text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
            Discover. Register.
            <br />
            Participate.
          </h1>
          <div className="mt-5 flex items-center gap-3">
            <span aria-hidden className="h-1 w-14 rounded-full bg-[#B8860B]" />
            <p className="text-sm font-semibold text-white/75">
              Make Every Moment Count at MIT-ADT
            </p>
          </div>
        </div>

        <p className="relative mt-10 hidden text-xs text-white/50 lg:block">
          © MIT-ADT University · Authorized campus users only
        </p>
      </aside>

      {/* Sign-in panel */}
      <main className="relative flex items-center justify-center bg-[#E6E4EE] px-4 py-10 dark:bg-background sm:px-8">
        <button
          type="button"
          aria-label={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
          title={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
          onClick={onThemeToggle}
          className="absolute right-4 top-4 rounded-full p-2 text-foreground transition-colors hover:bg-black/5 dark:hover:bg-white/10"
        >
          {theme === "light" ? <Moon className="size-5" /> : <Sun className="size-5" />}
        </button>

        <div className="w-full max-w-xl rounded-2xl border border-portal-hairline bg-card p-6 shadow-portal sm:p-8">
          <div className="flex items-center gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-[#B8860B]/15 text-[#B8860B]">
              <LockKeyhole className="size-5" aria-hidden />
            </span>
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground">Sign In</h2>
              <p className="text-xs text-muted-foreground">
                Choose your account, then enter the portal password.
              </p>
            </div>
          </div>

          <form onSubmit={submit} noValidate className="mt-6 space-y-5">
            <div
              role="radiogroup"
              aria-label="Select an account"
              className="grid grid-cols-1 gap-3"
            >
              {ROLES.map((role) => {
                const profile = ROLE_PROFILES[role];
                const active = role === selected;
                const RoleIcon = ROLE_ICONS[role];
                return (
                  <button
                    key={role}
                    type="button"
                    role="radio"
                    aria-checked={active}
                    onClick={() => selectRole(role)}
                    className={`flex w-full items-center gap-4 rounded-xl border p-3.5 text-left transition-all ${
                      active
                        ? "border-[#B8860B] bg-[#B8860B]/10 ring-2 ring-[#B8860B]/40"
                        : "border-portal-hairline bg-background hover:border-[#B8860B]/60 hover:bg-secondary"
                    }`}
                  >
                    <span
                      className={`flex size-12 shrink-0 items-center justify-center rounded-full text-sm font-extrabold ${
                        active ? "bg-[#B8860B] text-white" : "bg-[#360D3A] text-[#E3B341]"
                      }`}
                    >
                      {profile.initials}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-bold text-foreground">
                        {profile.name}
                      </span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {profile.subtitle}
                      </span>
                      <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5 text-[10px] font-bold text-foreground">
                        <RoleIcon className="size-3 text-[#B8860B]" aria-hidden />
                        {role}
                      </span>
                    </span>
                    {active && <CircleCheck className="size-5 shrink-0 text-[#B8860B]" aria-hidden />}
                  </button>
                );
              })}
            </div>

            <div>
              <label
                htmlFor="portal-password"
                className="mb-1.5 block text-xs font-bold uppercase tracking-widest text-muted-foreground"
              >
                Password{selectedProfile ? ` for ${selectedProfile.name}` : ""}
              </label>
              <div className="relative">
                <input
                  ref={passwordRef}
                  id="portal-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  disabled={!selected}
                  autoComplete="off"
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder={selected ? "Enter portal password" : "Select an account first"}
                  aria-invalid={error ? true : undefined}
                  aria-describedby={error ? "login-error login-hint" : "login-hint"}
                  className={`w-full rounded-lg border bg-background py-2.5 pl-3 pr-11 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 disabled:cursor-not-allowed disabled:opacity-60 ${
                    error
                      ? "border-destructive focus:border-destructive focus:ring-destructive/25"
                      : "border-portal-hairline focus:border-[#B8860B] focus:ring-[#B8860B]/25"
                  }`}
                />
                <button
                  type="button"
                  disabled={!selected}
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
                >
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>

              {error && (
                <p
                  id="login-error"
                  role="alert"
                  className="mt-2 flex items-start gap-1.5 text-xs font-semibold text-destructive"
                >
                  <CircleAlert className="mt-0.5 size-3.5 shrink-0" aria-hidden />
                  {error}
                </p>
              )}
              <p id="login-hint" className="mt-2 text-[11px] text-muted-foreground">
                Demo PIN: {DEMO_PASSWORD}
              </p>
            </div>

            <button
              type="submit"
              disabled={!selected}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#B8860B] py-3 text-sm font-bold text-white shadow-gold transition-colors hover:bg-[#B8860B]/90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <LogIn className="size-4" aria-hidden />
              Sign In
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}