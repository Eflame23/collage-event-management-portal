import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import {
  type CampusEvent,
  type EventDraft,
  type GatePass,
  type NotificationItem,
  INITIAL_EVENTS,
  INITIAL_NOTIFICATIONS,
  STUDENT,
} from "./data";
import {
  cancelEvent,
  cancelEventRemote,
  cancelRegistration,
  cancelRegistrationRemote,
  makeTicketId,
  publishEvent,
  publishEventRemote,
  registerForEvent,
  registerForEventRemote,
} from "./portal-logic";
import {
  DuplicateRegistrationError,
  fetchRegistrations,
  getErrorMessage,
  insertNotificationRow,
  isSupabaseConfigured,
  loadPortalData,
  markAllNotificationsRead,
} from "@/lib/supabase";
import { Header, type TabName } from "./Header";
import { DiscoveryTab } from "./DiscoveryTab";
import { CampusCalendar } from "./CampusCalendar";
import { OrganizerHub } from "./OrganizerHub";
import { PassesAlerts } from "./PassesAlerts";
import { RegisterModal } from "./RegisterModal";

interface ModalState {
  eventId: string;
  stage: "confirm" | "pass";
}

export function PortalApp() {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [events, setEvents] = useState<CampusEvent[]>([]);
  const [passes, setPasses] = useState<GatePass[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  // True only once data was loaded from Supabase. Otherwise the portal runs on
  // local demo data and never tries to write to the database.
  const [dbEnabled, setDbEnabled] = useState(false);
  const [activeTab, setActiveTab] = useState<TabName>("Discovery & Events");
  const [searchQuery, setSearchQuery] = useState("");
  const [category, setCategory] = useState("All Events");
  const [modal, setModal] = useState<ModalState | null>(null);
  const registeringRef = useRef(false);

  const registeredIds = useMemo(() => new Set(passes.map((p) => p.eventId)), [passes]);
  const unreadCount = notifications.filter((n) => n.unread).length;

  // 1. On load: fetch events / registrations / notifications (seeding on first run).
  useEffect(() => {
    let ignore = false;

    async function load() {
      if (!isSupabaseConfigured()) {
        console.warn(
          "VITE_SUPABASE_URL / VITE_SUPABASE_PUBLISHABLE_KEY are missing — using local demo data."
        );
        setEvents(INITIAL_EVENTS);
        setNotifications(INITIAL_NOTIFICATIONS);
        setLoading(false);
        return;
      }
      try {
        const data = await loadPortalData(STUDENT.name);
        if (ignore) return;
        setEvents(data.events);
        setPasses(data.passes);
        setNotifications(data.notifications);
        setDbEnabled(true);
      } catch (err) {
        if (ignore) return;
        console.error("Supabase load failed", err);
        toast.error(`Couldn't load from Supabase (${getErrorMessage(err)}). Showing local demo data.`);
        setEvents(INITIAL_EVENTS);
        setNotifications(INITIAL_NOTIFICATIONS);
      } finally {
        if (!ignore) setLoading(false);
      }
    }

    void load();
    return () => {
      ignore = true;
    };
  }, []);

  const addNotification = useCallback(
    (item: Omit<NotificationItem, "id" | "unread">) => {
      const createdAt = new Date().toISOString();
      const next: NotificationItem = {
        ...item,
        id: `ntf-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        unread: true,
      };
      setNotifications((prev) => [next, ...prev]);
      if (dbEnabled) {
        insertNotificationRow(next, createdAt).catch((err) => {
          console.error("Could not save notification", err);
          toast.error("Notification shown here but couldn't be saved to the database.");
        });
      }
    },
    [dbEnabled]
  );

  // 2. Register: insert into `registrations` + increment `events.taken`.
  const handleRegister = useCallback(
    async (event: CampusEvent) => {
      if (registeringRef.current) return;
      registeringRef.current = true;
      try {
        const result = dbEnabled
          ? await registerForEventRemote(
              events,
              passes,
              event.id,
              STUDENT.name,
              STUDENT.division,
              STUDENT.roll
            )
          : registerForEvent(events, passes, event.id, STUDENT.name, STUDENT.division);
        const updated = result.events.find((e) => e.id === event.id);
        if (updated) setEvents((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
        setPasses((prev) => [...prev, result.pass]);
        setModal({ eventId: event.id, stage: "pass" });
        addNotification({
          title: `Gate pass issued for ${event.title}`,
          body: `Ticket ${result.pass.ticketId} — 1 seat booked. Check My Passes & Alerts.`,
          time: "Just now",
          kind: "info",
        });
        toast.success(`Registered for ${event.title}! Your digital gate pass is ready.`);
      } catch (err) {
        toast.warning(getErrorMessage(err, "Registration failed."));
        if (err instanceof DuplicateRegistrationError) {
          // The database already has this pass (e.g. registered in another tab): sync and show it.
          try {
            setPasses(await fetchRegistrations(STUDENT.name));
            setModal({ eventId: event.id, stage: "pass" });
          } catch (syncErr) {
            console.error("Could not re-sync registrations", syncErr);
          }
        }
      } finally {
        registeringRef.current = false;
      }
    },
    [dbEnabled, events, passes, addNotification]
  );

  const handleViewPass = useCallback(
    (event: CampusEvent) => {
      if (!registeredIds.has(event.id)) {
        toast.warning(`No pass found for ${event.title} — register first.`);
        setModal({ eventId: event.id, stage: "confirm" });
        return;
      }
      setModal({ eventId: event.id, stage: "pass" });
    },
    [registeredIds]
  );

  const handleJoinWaitlist = useCallback(
    (event: CampusEvent) => {
      toast.info(`Added to waitlist for ${event.title} — we'll alert you if a seat opens up.`);
      addNotification({
        title: `Waitlist joined: ${event.title}`,
        body: "You'll receive an alert the moment a seat is released.",
        time: "Just now",
        kind: "info",
      });
    },
    [addNotification]
  );

  const handleCancelRegistration = useCallback(
    async (event: CampusEvent) => {
      try {
        const { events: updatedEvents, passes: updatedPasses } = dbEnabled
          ? await cancelRegistrationRemote(events, passes, event.id, STUDENT.name)
          : cancelRegistration(events, passes, event.id);
        setEvents(updatedEvents);
        setPasses(updatedPasses);
        setModal(null);
        addNotification({
          title: `Registration cancelled: ${event.title}`,
          body: "1 seat has been restored to the event's capacity.",
          time: "Just now",
          kind: "alert",
        });
        toast.info(`Registration cancelled for ${event.title}. 1 seat restored.`);
      } catch (err) {
        toast.error(getErrorMessage(err, "Couldn't cancel the registration."));
      }
    },
    [dbEnabled, events, passes, addNotification]
  );

  // 3a. Publish: insert into `events`.
  const handlePublish = useCallback(
    async (draft: EventDraft) => {
      try {
        const updatedEvents = dbEnabled
          ? await publishEventRemote(events, draft)
          : publishEvent(events, draft);
        setEvents(updatedEvents);
        addNotification({
          title: `New event published: ${draft.title}`,
          body: `${draft.category} · ${draft.venue} · ${draft.dateLabel}`,
          time: "Just now",
          kind: "info",
        });
        toast.success(`${draft.title} is live on the Discovery grid.`);
      } catch (err) {
        toast.error(`Couldn't publish ${draft.title}: ${getErrorMessage(err)}`);
      }
    },
    [dbEnabled, events, addNotification]
  );

  // 3b. Emergency cancel: set `cancelled = true` + insert an alert notification.
  const handleEmergencyCancel = useCallback(
    async (event: CampusEvent) => {
      try {
        const updatedEvents = dbEnabled
          ? await cancelEventRemote(events, event.id)
          : cancelEvent(events, event.id);
        setEvents(updatedEvents);
        addNotification({
          title: `EMERGENCY: ${event.title} cancelled`,
          body: `${event.dateLabel} at ${event.venue} — broadcast sent to all registered attendees.`,
          time: "Just now",
          kind: "alert",
        });
        toast.error(`${event.title} has been cancelled. Alert broadcast to all attendees.`);
      } catch (err) {
        toast.error(`Couldn't cancel ${event.title}: ${getErrorMessage(err)}`);
      }
    },
    [dbEnabled, events, addNotification]
  );

  // 4. Mark as read: update `unread = false` in `notifications`.
  const markAllRead = useCallback(() => {
    if (!notifications.some((n) => n.unread)) return;
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
    if (dbEnabled) {
      markAllNotificationsRead().catch((err) => {
        console.error("Could not mark notifications read", err);
        toast.error("Couldn't save read status to the database.");
      });
    }
  }, [dbEnabled, notifications]);

  const handleTabChange = useCallback(
    (tab: TabName) => {
      setActiveTab(tab);
      if (tab === "My Passes & Alerts") markAllRead();
    },
    [markAllRead]
  );

  const modalEvent = modal ? events.find((e) => e.id === modal.eventId) : undefined;

  return (
    <div
      className={`min-h-screen pb-20 text-foreground ${
        theme === "dark" ? "dark bg-background" : "bg-[#E6E4EE]"
      }`}
    >
      <Header
        activeTab={activeTab}
        onTabChange={handleTabChange}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        unreadCount={unreadCount}
        passesCount={passes.length}
        notifications={notifications}
        onMarkAllRead={markAllRead}
        theme={theme}
        onThemeToggle={() => setTheme((current) => (current === "light" ? "dark" : "light"))}
      />

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        {loading && (
          <div
            role="status"
            aria-label="Loading campus events"
            className="h-[28rem] animate-pulse rounded-2xl border border-slate-300/80 bg-card shadow-md dark:border-portal-hairline"
          />
        )}
        {!loading && activeTab === "Discovery & Events" && (
          <DiscoveryTab
            events={events}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            category={category}
            onCategoryChange={setCategory}
            registeredIds={registeredIds}
            onRegister={(event) => setModal({ eventId: event.id, stage: "confirm" })}
            onViewPass={handleViewPass}
            onJoinWaitlist={handleJoinWaitlist}
          />
        )}
        {!loading && activeTab === "Organizer Hub" && (
          <OrganizerHub events={events} onPublish={handlePublish} onEmergencyCancel={handleEmergencyCancel} />
        )}
        {!loading && activeTab === "Campus Calendar" && (
          <CampusCalendar
            events={events}
            registeredIds={registeredIds}
            onRegister={(event) => setModal({ eventId: event.id, stage: "confirm" })}
            onViewPass={handleViewPass}
            onJoinWaitlist={handleJoinWaitlist}
          />
        )}
        {!loading && activeTab === "My Passes & Alerts" && (
          <PassesAlerts
            passes={passes}
            events={events}
            notifications={notifications}
            onCancelRegistration={handleCancelRegistration}
          />
        )}
      </main>

      {modalEvent && modal && (
        <RegisterModal
          event={modalEvent}
          stage={modal.stage}
          ticketId={makeTicketId(modalEvent)}
          onClose={() => setModal(null)}
          onConfirm={() => handleRegister(modalEvent)}
        />
      )}

    </div>
  );
}